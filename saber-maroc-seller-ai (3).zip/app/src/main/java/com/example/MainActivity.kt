package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.NotificationDialog
import com.example.ui.components.ResultModal
import com.example.ui.components.SaberTopBar
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.credits.CreditsScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.library.LibraryHistoryScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.tools.AIToolsScreen
import com.example.ui.theme.*
import com.example.ui.viewmodel.SaberViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SaberViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SaberMarocTheme {
                // Moroccan RTL Direction support for natural Arabic and Darija reading
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    SaberMainApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun SaberMainApp(viewModel: SaberViewModel) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val unreadCount by viewModel.unreadNotificationsCount.collectAsState()
    val notifications by viewModel.userNotifications.collectAsState()
    val lastGeneratedItem by viewModel.lastGeneratedItem.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    var currentScreen by remember { mutableStateOf("HOME") }
    var selectedToolInitial by remember { mutableStateOf("VIDEO") }
    var isNotificationDialogOpen by remember { mutableStateOf(false) }

    // Toast watcher
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearToast()
        }
    }

    if (currentUser == null) {
        AuthScreen(
            viewModel = viewModel,
            onAuthSuccess = { currentScreen = "HOME" }
        )
    } else if (currentScreen == "ADMIN") {
        AdminDashboardScreen(
            viewModel = viewModel,
            onBack = { currentScreen = "HOME" }
        )
    } else {
        Scaffold(
            topBar = {
                SaberTopBar(
                    user = currentUser,
                    unreadCount = unreadCount,
                    onCreditsClick = { currentScreen = "CREDITS" },
                    onNotificationsClick = { isNotificationDialogOpen = true }
                )
            },
            bottomBar = {
                Column {
                    Divider(color = DarkBorder, thickness = 1.dp)
                    NavigationBar(
                        containerColor = DarkSurface,
                        contentColor = TextPrimary,
                        tonalElevation = 0.dp
                    ) {
                        val navItems = listOf(
                            Triple("HOME", "الرئيسية", Icons.Default.Home),
                            Triple("TOOLS", "الأدوات", Icons.Default.AutoAwesome),
                            Triple("CREDITS", "الرصيد", Icons.Default.MonetizationOn),
                            Triple("LIBRARY", "الأرشيف", Icons.Default.VideoLibrary),
                            Triple("PROFILE", "بروفيلي", Icons.Default.Person)
                        )

                        navItems.forEach { (route, label, icon) ->
                            val isSelected = currentScreen == route
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    if (route == "TOOLS") selectedToolInitial = "VIDEO"
                                    currentScreen = route
                                },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = if (isSelected) EmeraldPrimary else TextMuted
                                    )
                                },
                                label = {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) EmeraldPrimary else TextMuted,
                                        fontSize = 10.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = EmeraldContainer,
                                    selectedIconColor = EmeraldPrimary,
                                    selectedTextColor = EmeraldPrimary,
                                    unselectedIconColor = TextMuted,
                                    unselectedTextColor = TextMuted
                                )
                            )
                        }
                    }
                }
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    "HOME" -> {
                        HomeScreen(
                            user = currentUser,
                            onNavigateToTool = { tool ->
                                selectedToolInitial = tool
                                currentScreen = "TOOLS"
                            },
                            onNavigateToCredits = { currentScreen = "CREDITS" }
                        )
                    }

                    "TOOLS" -> {
                        AIToolsScreen(
                            viewModel = viewModel,
                            user = currentUser,
                            initialTool = selectedToolInitial,
                            onNavigateToCredits = { currentScreen = "CREDITS" }
                        )
                    }

                    "CREDITS" -> {
                        CreditsScreen(
                            viewModel = viewModel,
                            user = currentUser
                        )
                    }

                    "LIBRARY" -> {
                        LibraryHistoryScreen(
                            viewModel = viewModel
                        )
                    }

                    "PROFILE" -> {
                        ProfileScreen(
                            viewModel = viewModel,
                            user = currentUser,
                            onNavigateToAdmin = { currentScreen = "ADMIN" },
                            onNavigateToAuth = { currentScreen = "HOME" }
                        )
                    }
                }
            }
        }
    }

    // Modal when AI Content is generated
    lastGeneratedItem?.let { item ->
        ResultModal(
            item = item,
            onDismiss = { viewModel.clearLastGenerated() }
        )
    }

    // Notifications Dialog
    if (isNotificationDialogOpen) {
        NotificationDialog(
            notifications = notifications,
            onDismiss = { isNotificationDialogOpen = false },
            onMarkAllRead = {
                viewModel.markNotificationsAsRead()
            }
        )
    }
}
