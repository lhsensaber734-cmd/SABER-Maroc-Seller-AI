package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.SaberRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class SaberViewModel(application: Application) : AndroidViewModel(application) {

    val repository = SaberRepository.getInstance(application)

    // Current logged-in user
    val currentUserId = repository.currentUserId

    val currentUser: StateFlow<UserEntity?> = currentUserId
        .flatMapLatest { id ->
            if (id != null) repository.getCurrentUserFlow(id)
            else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // User Transactions & Ledger
    val userTransactions: StateFlow<List<TransactionEntity>> = currentUserId
        .flatMapLatest { id ->
            if (id != null) repository.getTransactionsForUser(id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Payment Requests
    val userPayments: StateFlow<List<PaymentRequestEntity>> = currentUserId
        .flatMapLatest { id ->
            if (id != null) repository.getPaymentsForUser(id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Generated Content Library
    val userContent: StateFlow<List<GeneratedContentEntity>> = currentUserId
        .flatMapLatest { id ->
            if (id != null) repository.getContentForUser(id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notifications
    val userNotifications: StateFlow<List<NotificationEntity>> = currentUserId
        .flatMapLatest { id ->
            if (id != null) repository.getNotificationsForUser(id)
            else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = currentUserId
        .flatMapLatest { id ->
            if (id != null) repository.getUnreadNotificationsCount(id)
            else flowOf(0)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Admin State
    val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingPayments: StateFlow<List<PaymentRequestEntity>> = repository.getPendingPayments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<PaymentRequestEntity>> = repository.getAllPayments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminNotifications: StateFlow<List<NotificationEntity>> = repository.getAdminNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _dashboardStats = MutableStateFlow(DashboardStats())
    val dashboardStats: StateFlow<DashboardStats> = _dashboardStats.asStateFlow()

    // UI Loading & Feedback States
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _generationProgressText = MutableStateFlow("")
    val generationProgressText: StateFlow<String> = _generationProgressText.asStateFlow()

    private val _lastGeneratedItem = MutableStateFlow<GeneratedContentEntity?>(null)
    val lastGeneratedItem: StateFlow<GeneratedContentEntity?> = _lastGeneratedItem.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Chat History
    private val _chatMessages = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "مرحباً بك يا بطل التجارة الإلكترونية 🇲🇦!" to "أنا صابر، مستشارك الذكي للتجارة بالمغرب. كيفاش نقدر نعاونك تطور مبيعاتك وتصاوب إعلانات ناجحة اليوم؟"
    ))
    val chatMessages: StateFlow<List<Pair<String, String>>> = _chatMessages.asStateFlow()

    // Selected Language
    private val _selectedLanguage = MutableStateFlow("الدارجة المغربية")
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    init {
        refreshAdminStats()
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
    }

    fun clearToast() { _toastMessage.value = null }
    fun clearError() { _errorMessage.value = null }
    fun clearLastGenerated() { _lastGeneratedItem.value = null }

    // --- Authentication ---
    fun register(name: String, email: String, pass: String, phone: String, business: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            if (name.isBlank() || email.isBlank() || pass.isBlank()) {
                _errorMessage.value = "يرجى ملء جميع الحقول المطلوبة."
                return@launch
            }
            val res = repository.registerUser(name, email, pass, phone, business)
            if (res.isSuccess) {
                _toastMessage.value = "تم إنشاء الحساب بنجاح! مبروك 40 نقطة تجريبية مجانية 🎁"
                refreshAdminStats()
                onSuccess()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "فشل التسجيل"
            }
        }
    }

    fun login(email: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val res = repository.loginUser(email, pass)
            if (res.isSuccess) {
                _toastMessage.value = "مرحباً بك مجدداً ${res.getOrNull()?.fullName} 👋"
                refreshAdminStats()
                onSuccess()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "فشل تسجيل الدخول"
            }
        }
    }

    fun resetPassword(email: String, newPass: String) {
        viewModelScope.launch {
            val res = repository.resetPassword(email, newPass)
            if (res.isSuccess) {
                _toastMessage.value = res.getOrThrow()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "فشل إعادة تعيين كلمة المرور"
            }
        }
    }

    fun logout() {
        repository.logout()
        _toastMessage.value = "تم تسجيل الخروج."
    }

    fun switchUser(userId: String) {
        repository.setCurrentUserId(userId)
        _toastMessage.value = "تم التبديل إلى الحساب: $userId"
    }

    // --- Video Generator ---
    fun generateVideo(
        productName: String,
        description: String,
        priceDh: String,
        audience: String,
        objective: String,
        language: String,
        voiceStyle: String,
        style: String,
        durationSeconds: Int,
        aspectRatio: String,
        imageBitmap: Bitmap?
    ) {
        val user = currentUser.value
        if (user == null) {
            _errorMessage.value = "يرجى تسجيل الدخول أولاً."
            return
        }

        viewModelScope.launch {
            _isGenerating.value = true
            _generationProgressText.value = "جارٍ تحليل المنتوج وصياغة السكربت بالدارجة المغربية..."
            
            val result = repository.generateVideoAd(
                userId = user.userId,
                productName = productName,
                productDescription = description,
                priceDh = priceDh,
                targetAudience = audience,
                objective = objective,
                language = language,
                voiceStyle = voiceStyle,
                videoStyle = style,
                durationSeconds = durationSeconds,
                aspectRatio = aspectRatio,
                productImageBitmap = imageBitmap
            )

            _isGenerating.value = false
            if (result.isSuccess) {
                val item = result.getOrThrow()
                _lastGeneratedItem.value = item
                _toastMessage.value = "تم إنشاء فيديو الإعلان بنجاح! 🎬"
                refreshAdminStats()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "فشل إنشاء الفيديو"
            }
        }
    }

    // --- Product Opportunity Analyzer ---
    fun analyzeProduct(
        productName: String,
        category: String,
        costPriceDh: String,
        country: String,
        imageBitmap: Bitmap?
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            _isGenerating.value = true
            _generationProgressText.value = "جارٍ دراسة السوق المغربي وهوامش الربح ونسب التوصيل (COD)..."
            val result = repository.analyzeProductOpportunity(user.userId, productName, category, costPriceDh, country, imageBitmap)
            _isGenerating.value = false
            if (result.isSuccess) {
                _lastGeneratedItem.value = result.getOrThrow()
                _toastMessage.value = "تم إكمال دراسة الجدوى بنجاح! 📊"
                refreshAdminStats()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "فشل التحليل"
            }
        }
    }

    // --- Darija Script Generator ---
    fun generateScript(productName: String, scriptType: String, tone: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            _isGenerating.value = true
            _generationProgressText.value = "جارٍ كتابة سكربت مغربي إقناعي عالي التحويل..."
            val result = repository.generateScriptContent(user.userId, productName, scriptType, tone)
            _isGenerating.value = false
            if (result.isSuccess) {
                _lastGeneratedItem.value = result.getOrThrow()
                _toastMessage.value = "تم تجهيز السكربت بالدارجة! 📝"
                refreshAdminStats()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "فشل السكربت"
            }
        }
    }

    // --- Studio Photoshoot Generator ---
    fun generateImage(productName: String, stylePrompt: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            _isGenerating.value = true
            _generationProgressText.value = "جارٍ تصوير المنتوج فاستوديو الذكاء الاصطناعي..."
            val result = repository.generatePhotoshootImage(user.userId, productName, stylePrompt)
            _isGenerating.value = false
            if (result.isSuccess) {
                _lastGeneratedItem.value = result.getOrThrow()
                _toastMessage.value = "تم إنشاء الصورة بنجاح! 📸"
                refreshAdminStats()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "فشلت الصورة"
            }
        }
    }

    // --- AI Chat ---
    fun sendChatMessage(msg: String) {
        if (msg.isBlank()) return
        val currentHistory = _chatMessages.value.toMutableList()
        currentHistory.add(msg to "...")
        _chatMessages.value = currentHistory

        viewModelScope.launch {
            val userHistory = _chatMessages.value.dropLast(1).filter { it.second != "..." }
            val res = com.example.data.remote.AIServiceEngine.chatWithSaberConsultant(msg, userHistory)
            val reply = if (res.isSuccess) res.getOrThrow() else "عذراً، حدث خطأ في الاتصال. المرجو المحاولة مرة أخرى."
            
            val updated = _chatMessages.value.toMutableList()
            if (updated.isNotEmpty()) {
                updated[updated.lastIndex] = msg to reply
            }
            _chatMessages.value = updated
        }
    }

    // --- Cash Plus Top-up Submission ---
    fun submitPayment(
        packageDh: Double,
        credits: Int,
        method: String,
        refNumber: String,
        receiptBitmap: Bitmap?,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            _isGenerating.value = true
            _generationProgressText.value = "جارٍ فحص الوصل وإرسال طلب الشحن للإدارة..."
            val result = repository.submitCashPlusPayment(user.userId, packageDh, credits, method, refNumber, receiptBitmap)
            _isGenerating.value = false
            if (result.isSuccess) {
                _toastMessage.value = "تم إرسال طلب الشحن بنجاح! سيتم تفعيل $credits نقطة فور مراجعة الوصل ⏳"
                refreshAdminStats()
                onSuccess()
            } else {
                _errorMessage.value = result.exceptionOrNull()?.message ?: "فشل إرسال الطلب"
            }
        }
    }

    // --- Admin Operations ---
    fun approvePayment(requestId: String) {
        viewModelScope.launch {
            val res = repository.confirmPayment(requestId)
            if (res.isSuccess) {
                _toastMessage.value = "تم تأكيد الدفع وإضافة الرصيد للمستخدم بنجاح! ✅"
                refreshAdminStats()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "فشل التأكيد"
            }
        }
    }

    fun rejectPayment(requestId: String, reason: String) {
        viewModelScope.launch {
            val res = repository.rejectPayment(requestId, reason)
            if (res.isSuccess) {
                _toastMessage.value = "تم رفض الطلب وإشعار المستخدم. ❌"
                refreshAdminStats()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "فشل الرفض"
            }
        }
    }

    fun adminAdjustCredits(userId: String, deltaCredits: Int, note: String) {
        viewModelScope.launch {
            val res = repository.adminAdjustUserCredits(userId, deltaCredits, note)
            if (res.isSuccess) {
                _toastMessage.value = "تم تعديل رصيد المستخدم بنجاح! ⚡"
                refreshAdminStats()
            } else {
                _errorMessage.value = res.exceptionOrNull()?.message ?: "فشل التعديل"
            }
        }
    }

    fun updateConfig(key: String, value: String) {
        viewModelScope.launch {
            repository.updateAppConfig(key, value)
            _toastMessage.value = "تم حفظ الإعدادات بنجاح. 💾"
        }
    }

    fun deleteSavedContent(item: GeneratedContentEntity) {
        viewModelScope.launch {
            repository.deleteContent(item)
            _toastMessage.value = "تم حذف العنصر من المكتبة."
        }
    }

    fun markNotificationsAsRead() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.markNotificationsRead(user.userId)
        }
    }

    fun refreshAdminStats() {
        viewModelScope.launch {
            _dashboardStats.value = repository.getDashboardStats()
        }
    }
}
