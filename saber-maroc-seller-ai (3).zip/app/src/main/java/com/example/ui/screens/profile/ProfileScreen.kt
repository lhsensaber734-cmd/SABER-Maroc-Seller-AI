package com.example.ui.screens.profile

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SaberViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProfileScreen(
    viewModel: SaberViewModel,
    user: UserEntity?,
    onNavigateToAdmin: () -> Unit,
    onNavigateToAuth: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allUsers by viewModel.allUsers.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()

    var isSwitchAccountDialogOpen by remember { mutableStateOf(false) }
    var isResetPasswordDialogOpen by remember { mutableStateOf(false) }
    var newPasswordInput by remember { mutableStateOf("") }

    val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
    ) {
        // User Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(if (user?.isAdmin == true) MoroccanGold else EmeraldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (user?.isAdmin == true) Icons.Default.AdminPanelSettings else Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = user?.fullName ?: "مستخدم صابر",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Text(
                        text = user?.businessType ?: "E-commerce Seller",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Unique User ID pill with 1-click copy
                    Surface(
                        color = DarkSurfaceElevated,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.clickable {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("SABER User ID", user?.userId ?: ""))
                            Toast.makeText(context, "تم نسخ معرف المستخدم: ${user?.userId} 📋", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "معرف الحساب:",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                            Text(
                                text = user?.userId ?: "SBR-XXXXXX",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MoroccanGold
                            )
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = TextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Account Details & Trial Status
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "تفاصيل الحساب والرصيد 👤",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Divider(color = DarkBorder)

                    ProfileInfoRow(label = "البريد الإلكتروني:", value = user?.email ?: "")
                    ProfileInfoRow(label = "رقم الهاتف:", value = user?.phone ?: "")
                    ProfileInfoRow(
                        label = "تاريخ الانضمام:",
                        value = if (user != null) dateFormat.format(Date(user.createdAt)) else ""
                    )
                    ProfileInfoRow(
                        label = "حالة الحساب:",
                        value = if (user?.isAdmin == true) "مسؤول النظام (Admin)" else "بائع نشط (Active Seller)"
                    )
                    ProfileInfoRow(
                        label = "رصيد النقاط المتاحة:",
                        value = "${user?.creditsBalance ?: 0} نقطة",
                        valueColor = MoroccanGold
                    )
                }
            }
        }

        // ADMIN DASHBOARD BUTTON (Highlighted for Admins)
        if (user?.isAdmin == true) {
            item {
                Button(
                    onClick = onNavigateToAdmin,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MoroccanGold),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = OnGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("فتح لوحة تحكم المسؤول (Admin Dashboard)", color = OnGold, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Language & Dialect Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = EmeraldPrimary)
                        Text(
                            text = "لغة الإعلانات والواجهة 🇲🇦",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    listOf(
                        "الدارجة المغربية" to "الدارجة المغربية (Moroccan Darija) 🇲🇦",
                        "العربية الفصحى" to "العربية (Arabic)",
                        "Français" to "Français (French)",
                        "English" to "English (English)"
                    ).forEach { (code, title) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.setLanguage(code) }
                                .padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = selectedLanguage == code,
                                onClick = { viewModel.setLanguage(code) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                    }
                }
            }
        }

        // Switch Account & Quick Actions
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "إدارة الحسابات والأمان 🔒",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    OutlinedButton(
                        onClick = { isSwitchAccountDialogOpen = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.SwitchAccount, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تبديل الحساب (بائع / Admin)")
                    }

                    OutlinedButton(
                        onClick = { isResetPasswordDialogOpen = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تغيير كلمة المرور")
                    }

                    Button(
                        onClick = {
                            viewModel.logout()
                            onNavigateToAuth()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusError.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = null, tint = StatusError)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تسجيل الخروج من الحساب", color = StatusError, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Switch Account Dialog
    if (isSwitchAccountDialogOpen) {
        AlertDialog(
            onDismissRequest = { isSwitchAccountDialogOpen = false },
            title = { Text("اختر الحساب المراد التبديل إليه 👥", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    allUsers.forEach { u ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (u.userId == user?.userId) EmeraldPrimary.copy(alpha = 0.2f) else DarkSurface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.switchUser(u.userId)
                                    isSwitchAccountDialogOpen = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(u.fullName, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                                    Text("${u.email} • ${u.userId}", color = TextSecondary, fontSize = 11.sp)
                                }
                                Text("${u.creditsBalance} نقطة", color = MoroccanGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { isSwitchAccountDialogOpen = false }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Reset Password Dialog
    if (isResetPasswordDialogOpen) {
        AlertDialog(
            onDismissRequest = { isResetPasswordDialogOpen = false },
            title = { Text("تحديث كلمة المرور", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newPasswordInput,
                        onValueChange = { newPasswordInput = it },
                        label = { Text("كلمة المرور الجديدة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (user != null && newPasswordInput.isNotBlank()) {
                            viewModel.resetPassword(user.email, newPasswordInput)
                            isResetPasswordDialogOpen = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("حفظ كلمة المرور")
                }
            },
            dismissButton = {
                TextButton(onClick = { isResetPasswordDialogOpen = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun ProfileInfoRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = valueColor)
    }
}
