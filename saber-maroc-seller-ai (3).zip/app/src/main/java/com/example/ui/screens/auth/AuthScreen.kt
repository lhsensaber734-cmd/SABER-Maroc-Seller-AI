package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.SaberViewModel

@Composable
fun AuthScreen(
    viewModel: SaberViewModel,
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedAuthTab by remember { mutableStateOf(0) } // 0 = Login, 1 = Register, 2 = Forgot

    var loginEmail by remember { mutableStateOf("seller@saber.ma") }
    var loginPass by remember { mutableStateOf("123456") }

    var regName by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regPass by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regBusiness by remember { mutableStateOf("التجارة الإلكترونية والدفع عند الاستلام (COD)") }

    var forgotEmail by remember { mutableStateOf("") }
    var forgotNewPass by remember { mutableStateOf("") }

    val errorMessage by viewModel.errorMessage.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(vertical = 32.dp)
    ) {
        item {
            // App Logo
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(EmeraldPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "SABER",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "SABER Maroc Seller AI 🇲🇦",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = "المنصة الذكية الأولى للبائعين وصناع المحتوى بالمغرب",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Auth Tabs
            TabRow(
                selectedTabIndex = selectedAuthTab,
                containerColor = DarkSurfaceVariant,
                contentColor = EmeraldPrimary,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                divider = {}
            ) {
                Tab(
                    selected = selectedAuthTab == 0,
                    onClick = { selectedAuthTab = 0 },
                    text = { Text("تسجيل الدخول", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedAuthTab == 1,
                    onClick = { selectedAuthTab = 1 },
                    text = { Text("حساب جديد 🎁", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Error notice
            errorMessage?.let { err ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = StatusError.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                ) {
                    Text(
                        text = err,
                        color = StatusError,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Card form
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (selectedAuthTab) {
                        0 -> {
                            // Login Form
                            Text("تسجيل الدخول إلى حسابك", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)

                            OutlinedTextField(
                                value = loginEmail,
                                onValueChange = { loginEmail = it },
                                label = { Text("البريد الإلكتروني") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth().testTag("login_email_input"),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = loginPass,
                                onValueChange = { loginPass = it },
                                label = { Text("كلمة المرور") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth().testTag("login_password_input"),
                                singleLine = true
                            )

                            Button(
                                onClick = {
                                    viewModel.login(loginEmail, loginPass, onAuthSuccess)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("login_submit_button")
                            ) {
                                Text("دخول إلى صابر AI", fontWeight = FontWeight.Bold)
                            }

                            // Quick credentials helper
                            Surface(
                                color = DarkSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("💡 حسابات تجريبية سريعة:", style = MaterialTheme.typography.labelSmall, color = MoroccanGold, fontWeight = FontWeight.Bold)
                                    Text("بائع: seller@saber.ma (كلمة السر: 123456)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                    Text("مسؤول: admin@saber.ma (كلمة السر: admin123)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                }
                            }
                        }

                        1 -> {
                            // Register Form
                            Text("إنشاء حساب بائع جديد 🎁", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("سجل دابا واحصل على 40 نقطة تجريبية مجانية لصناعة الفيديوهات!", style = MaterialTheme.typography.bodySmall, color = EmeraldPrimary)

                            OutlinedTextField(
                                value = regName,
                                onValueChange = { regName = it },
                                label = { Text("الاسم الكامل / اسم المتجر") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth().testTag("register_name_input"),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = regEmail,
                                onValueChange = { regEmail = it },
                                label = { Text("البريد الإلكتروني") },
                                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth().testTag("register_email_input"),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = regPhone,
                                onValueChange = { regPhone = it },
                                label = { Text("رقم الهاتف / الواتساب بالمغرب") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            OutlinedTextField(
                                value = regPass,
                                onValueChange = { regPass = it },
                                label = { Text("كلمة المرور") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier.fillMaxWidth().testTag("register_password_input"),
                                singleLine = true
                            )

                            Button(
                                onClick = {
                                    viewModel.register(regName, regEmail, regPass, regPhone, regBusiness, onAuthSuccess)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("register_submit_button")
                            ) {
                                Text("إنشاء الحساب وتفعيل 40 نقطة 🚀", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
