package com.example.ui.screens.credits

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CreditPackage
import com.example.data.model.UserEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SaberViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CreditsScreen(
    viewModel: SaberViewModel,
    user: UserEntity?,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val payments by viewModel.userPayments.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()

    var selectedPackage by remember {
        mutableStateOf(
            CreditPackage("PKG-50", "باقة البائع النشط", 50.0, 85, "+10 نقاط بونص 🎁", true, "تكفي لصنع فيديوهات إعلانية وتحليل 10 منتجات رابحة")
        )
    }

    var isPaymentDialogOpen by remember { mutableStateOf(false) }
    var refNumberInput by remember { mutableStateOf("") }
    var selectedPaymentMethod by remember { mutableStateOf("Cash Plus (كاش بلوس)") }

    val packages = listOf(
        CreditPackage("PKG-20", "باقة التجربة السريعة", 20.0, 30, "", false, "مناسبة لتجربة إنشاء فيديو إعلاني وتحليل سريع"),
        CreditPackage("PKG-50", "باقة البائع النشط (الأكثر طلباً)", 50.0, 85, "+10 نقاط بونص 🎁", true, "تكفي لصنع فيديوهات إعلانية وتحليل 10 منتجات رابحة"),
        CreditPackage("PKG-100", "باقة المحترفين والدروب شيبينغ", 100.0, 200, "+30 نقطة بونص 🚀", false, "مثالية لإطلاق حملات إعلانية وتكبير المبيعات"),
        CreditPackage("PKG-200", "باقة الوكالات والبراندات", 200.0, 450, "+90 نقطة بونص 👑", false, "أقصى توفير لصناع المحتوى والمسوقين المحترفين")
    )

    val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
    ) {
        // Balance Overview Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldContainer),
                modifier = Modifier.fillMaxWidth().testTag("credits_summary_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "رصيدك الحالي في المنصة",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "${user?.creditsBalance ?: 0}",
                                    style = MaterialTheme.typography.displaySmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MoroccanGold
                                )
                                Text(
                                    text = "SABER Credits",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(GoldContainer.copy(alpha = 0.5f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = MoroccanGold,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "💡 تُستخدم النقاط لإنشاء الفيديوهات الإعلانية بالدارجة وتحليل المنتوجات الرابحة. الرصيد يبقى دائماً في حسابك ولا ينتهي أبداً.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Section Title: Packages
        item {
            Text(
                text = "اختر باقة الشحن المناسبة لك 💳",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        // Packages Grid/List
        items(packages) { pkg ->
            val isSelected = selectedPackage.id == pkg.id
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) DarkSurfaceElevated else DarkSurfaceVariant
                ),
                border = androidx.compose.foundation.BorderStroke(
                    if (isSelected) 2.dp else 1.dp,
                    if (isSelected) MoroccanGold else DarkBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { selectedPackage = pkg }
                    .testTag("package_${pkg.priceDh.toInt()}_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = pkg.name,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (pkg.isPopular) {
                                Badge(containerColor = EmeraldPrimary) {
                                    Text("الأكثر طلباً", color = Color.White, fontSize = 10.sp)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = pkg.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                        if (pkg.bonusTag.isNotBlank()) {
                            Text(
                                text = pkg.bonusTag,
                                style = MaterialTheme.typography.labelSmall,
                                color = MoroccanGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Column(
                        horizontalAlignment = Alignment.End,
                        modifier = Modifier.padding(start = 12.dp)
                    ) {
                        Text(
                            text = "${pkg.priceDh.toInt()} درهم",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MoroccanGold
                        )
                        Text(
                            text = "${pkg.credits} نقطة",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldPrimary
                        )
                    }
                }
            }
        }

        // Cash Plus & Transfer Info Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = EmeraldPrimary
                        )
                        Text(
                            text = "طريقة الدفع عبر Cash Plus / البنك 🇲🇦",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Surface(
                        color = DarkBackground,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("اسم المستفيد (Beneficiary):", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text("SABER MAROC SARL", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("RIB البنكي / رقم الحساب:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("3000 0123 4567 8901 2345 6789", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MoroccanGold)
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            clipboard.setPrimaryClip(ClipData.newPlainText("RIB", "300001234567890123456789"))
                                            Toast.makeText(context, "تم نسخ الـ RIB بنجاح 📋", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("المدينة والوكالات:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Text("جميع وكالات Cash Plus وتطبيق الهاتف", style = MaterialTheme.typography.labelSmall, color = TextPrimary)
                            }
                        }
                    }

                    Button(
                        onClick = { isPaymentDialogOpen = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MoroccanGold),
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("i_sent_payment_button")
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = OnGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "لقد أرسلت الدفع (${selectedPackage.priceDh.toInt()} DH) 📤",
                            color = OnGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Section Title: Payment History
        item {
            Text(
                text = "سجل طلبات الشحن الخاصة بك ⏳",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (payments.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("لم تقم بإرسال أي طلب شحن حتى الآن.", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        } else {
            items(payments) { p ->
                val statusColor = when (p.status) {
                    "CONFIRMED" -> StatusSuccess
                    "REJECTED" -> StatusError
                    else -> StatusPending
                }
                val statusText = when (p.status) {
                    "CONFIRMED" -> "تم التأكيد وإضافة الرصيد ✅"
                    "REJECTED" -> "تم الرفض ❌"
                    else -> "قيد المراجعة والتحقق ⏳"
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "طلب شحن: ${p.creditsRequested} نقطة",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "${p.packageDh.toInt()} درهم",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MoroccanGold
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("رقم العملية: ${p.referenceNumber}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Text(dateFormat.format(Date(p.dateTimestamp)), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }
                        Surface(
                            color = statusColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = statusText,
                                style = MaterialTheme.typography.labelSmall,
                                color = statusColor,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Payment Submission Dialog
    if (isPaymentDialogOpen) {
        AlertDialog(
            onDismissRequest = { isPaymentDialogOpen = false },
            title = {
                Text("تأكيد إرسال الدفع عبر Cash Plus 🇲🇦", fontWeight = FontWeight.Bold, color = TextPrimary)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "الباقة المختارة: ${selectedPackage.name}\nالمبلغ: ${selectedPackage.priceDh.toInt()} درهم (${selectedPackage.credits} نقطة)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MoroccanGold
                    )
                    OutlinedTextField(
                        value = refNumberInput,
                        onValueChange = { refNumberInput = it },
                        label = { Text("رقم الوصل أو المرجع (Reference Code)") },
                        placeholder = { Text("مثال: CP-829103") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Text(
                        text = "💡 تم التقاط الوصل تلقائياً وسيتم مراجعته وتفعيل النقاط فوراً.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitPayment(
                            packageDh = selectedPackage.priceDh,
                            credits = selectedPackage.credits,
                            method = selectedPaymentMethod,
                            refNumber = refNumberInput,
                            receiptBitmap = null
                        ) {
                            isPaymentDialogOpen = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Text("إرسال للمراجعة")
                }
            },
            dismissButton = {
                TextButton(onClick = { isPaymentDialogOpen = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            }
        )
    }
}
