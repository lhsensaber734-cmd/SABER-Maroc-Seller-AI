package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SABER Maroc Seller AI - Sleek Interface Palette
val EmeraldPrimary = Color(0xFF059669) // Emerald-600
val EmeraldPrimaryDark = Color(0xFF047857) // Emerald-700
val EmeraldPrimaryLight = Color(0xFF10B981) // Emerald-500
val EmeraldContainer = Color(0xFFECFDF5) // Emerald-50
val EmeraldBorder = Color(0xFFD1FAE5) // Emerald-100
val OnEmerald = Color(0xFFFFFFFF)
val OnEmeraldContainer = Color(0xFF065F46) // Emerald-800

val MoroccanGold = Color(0xFFD97706) // Amber-600
val MoroccanGoldDark = Color(0xFFB45309) // Amber-700
val GoldContainer = Color(0xFFFEF3C7) // Amber-100
val GoldBorder = Color(0xFFFDE68A) // Amber-200
val OnGold = Color(0xFF78350F) // Amber-900

val MoroccanRed = Color(0xFFE11D48) // Rose-600
val MoroccanRedContainer = Color(0xFFFFF1F2) // Rose-50

// Sleek Light Surfaces & Backgrounds
val DarkBackground = Color(0xFFF7F9FC) // Sleek Canvas Background
val DarkSurface = Color(0xFFFFFFFF) // Crisp Pure White Surface
val DarkSurfaceVariant = Color(0xFFF8FAFC) // Slate-50 Subsurface
val DarkSurfaceElevated = Color(0xFFFFFFFF) // Elevated Card
val DarkBorder = Color(0xFFF1F5F9) // Slate-100 Border
val DarkBorderMedium = Color(0xFFE2E8F0) // Slate-200 Border

// Text Hierarchy
val TextPrimary = Color(0xFF0F172A) // Slate-900 Primary Text
val TextSecondary = Color(0xFF475569) // Slate-600 Secondary Text
val TextMuted = Color(0xFF94A3B8) // Slate-400 Muted / Captions

// Soft Accent Badges
val SoftBlueBg = Color(0xFFEFF6FF)
val SoftBlueText = Color(0xFF2563EB)
val SoftAmberBg = Color(0xFFFFFBEB)
val SoftAmberText = Color(0xFFD97706)
val SoftPurpleBg = Color(0xFFFAF5FF)
val SoftPurpleText = Color(0xFF9333EA)
val SoftRoseBg = Color(0xFFFFF1F2)
val SoftRoseText = Color(0xFFE11D48)
val SoftEmeraldBg = Color(0xFFECFDF5)
val SoftEmeraldText = Color(0xFF059669)

// Status Colors
val StatusSuccess = Color(0xFF059669)
val StatusWarning = Color(0xFFD97706)
val StatusError = Color(0xFFEF4444)
val StatusPending = Color(0xFF0284C7)
