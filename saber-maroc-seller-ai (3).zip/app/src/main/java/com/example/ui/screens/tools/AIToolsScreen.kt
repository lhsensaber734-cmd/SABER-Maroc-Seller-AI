package com.example.ui.screens.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.SaberViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIToolsScreen(
    viewModel: SaberViewModel,
    user: UserEntity?,
    initialTool: String = "VIDEO",
    onNavigateToCredits: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(initialTool) }

    // Video Generator State
    var videoProductName by remember { mutableStateOf("مفرمة وخلاط كهربائي ذكي 4 في 1") }
    var videoDescription by remember { mutableStateOf("مفرمة قوية لفرم اللحوم والخضار في 10 ثواني فقط مع شفرات ستانلس ستيل غير قابلة للصدأ ومحرك نحاسي قوي") }
    var videoPriceDh by remember { mutableStateOf("199") }
    var videoAudience by remember { mutableStateOf("نساء وعائلات في كل مدن المغرب 🇲🇦") }
    var videoObjective by remember { mutableStateOf("تحقيق مبيعات مباشرة والدفع عند الاستلام (COD Sales)") }
    var videoLanguage by remember { mutableStateOf("الدارجة المغربية") }
    var videoVoice by remember { mutableStateOf("شاب مغربي تجاري حماسي (Commercial)") }
    var videoStyle by remember { mutableStateOf("إعلان تجاري للتيك توك والريلز (TikTok UGC / Reel)") }
    var videoDuration by remember { mutableStateOf(8) }
    var videoRatio by remember { mutableStateOf("9:16") }

    // Product Analyzer State
    var anaProductName by remember { mutableStateOf("سماعات بلوتوث عازلة للضوضاء Pro") }
    var anaCategory by remember { mutableStateOf("إلكترونيات وإكسسوارات الهواتف") }
    var anaCostDh by remember { mutableStateOf("45") }
    var anaCountry by remember { mutableStateOf("المغرب (Morocco)") }

    // Script Generator State
    var scriptProduct by remember { mutableStateOf("سيروم زيت الأركان الطبيعي للشعر والوجه") }
    var scriptType by remember { mutableStateOf("فيديو UGC تيك توك عفوي ومقنع") }
    var scriptTone by remember { mutableStateOf("عفوي وحماسي ومبهر (Viral TikTok Hook)") }

    // Photoshoot State
    var photoProduct by remember { mutableStateOf("قارورة عطر فاخرة مغربية") }
    var photoStyle by remember { mutableStateOf("في رياض مغربي فاخر مع رخام ونقش أندلسي وإضاءة شمس دافئة") }

    // Chat Message
    var chatInput by remember { mutableStateOf("") }
    val chatMessages by viewModel.chatMessages.collectAsState()

    val isGenerating by viewModel.isGenerating.collectAsState()
    val progressText by viewModel.generationProgressText.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Tool Selection Horizontal Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val tools = listOf(
                "VIDEO" to "🎬 صانع الفيديوهات (الرئيسي)",
                "ANALYSIS" to "📊 دراسة وتحليل المنتوج",
                "SCRIPT" to "📝 سكربتات الدارجة",
                "IMAGE" to "📸 تصوير ستوديو",
                "CHAT" to "💬 مستشار التجارة"
            )
            items(tools) { (key, label) ->
                FilterChip(
                    selected = selectedTab == key,
                    onClick = { selectedTab = key },
                    label = { Text(label, fontWeight = if (selectedTab == key) FontWeight.Bold else FontWeight.Normal) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldPrimary,
                        selectedLabelColor = Color.White,
                        containerColor = DarkSurfaceVariant,
                        labelColor = TextSecondary
                    )
                )
            }
        }

        // Active Tool Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
        ) {
            when (selectedTab) {
                "VIDEO" -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "إعدادات الفيديو الإعلاني بالدارجة 🎬",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    val cost = when (videoDuration) { 15 -> 50; 20 -> 70; else -> 30 }
                                    Badge(containerColor = GoldContainer) {
                                        Text("$cost نقطة", color = MoroccanGold, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Quick Templates Preset Selector
                                Text("💡 نماذج منتجات جاهزة للتجربة:", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    SuggestionChip(
                                        onClick = {
                                            videoProductName = "مفرمة وخلاط كهربائي ذكي 4 في 1"
                                            videoPriceDh = "199"
                                            videoDescription = "مفرمة لفرم اللحم والخضار في 10 ثواني فقط، موفرة للوقت والجهد مع ضمانة سنة"
                                        },
                                        label = { Text("🥩 مفرمة خضار", fontSize = 11.sp) }
                                    )
                                    SuggestionChip(
                                        onClick = {
                                            videoProductName = "ساعة ذكية Smartwatch Ultra مع 3 أحزمة"
                                            videoPriceDh = "249"
                                            videoDescription = "ساعة ذكية مقاومة للماء مع قياس دقات القلب والاتصال البلوتوث وبطارية تدوم 7 أيام"
                                        },
                                        label = { Text("⌚ ساعة ألترا", fontSize = 11.sp) }
                                    )
                                    SuggestionChip(
                                        onClick = {
                                            videoProductName = "مصل زيت الأركان الملكي الطبيعي"
                                            videoPriceDh = "149"
                                            videoDescription = "زيت أركان طبيعي 100% مستخلص على البارد لتغذية البشرة وتنعيم الشعر وإزالة التجاعيد"
                                        },
                                        label = { Text("🌿 زيت أركان", fontSize = 11.sp) }
                                    )
                                }

                                // Product Name Input
                                OutlinedTextField(
                                    value = videoProductName,
                                    onValueChange = { videoProductName = it },
                                    label = { Text("اسم المنتوج / السلعة") },
                                    modifier = Modifier.fillMaxWidth().testTag("product_name_input"),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = EmeraldPrimary,
                                        unfocusedBorderColor = DarkBorder
                                    )
                                )

                                // Product Description
                                OutlinedTextField(
                                    value = videoDescription,
                                    onValueChange = { videoDescription = it },
                                    label = { Text("وصف المنتوج وأهم ميزاته للزبون المغربي") },
                                    modifier = Modifier.fillMaxWidth().testTag("product_desc_input"),
                                    minLines = 2,
                                    maxLines = 4,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = EmeraldPrimary,
                                        unfocusedBorderColor = DarkBorder
                                    )
                                )

                                // Price in DH
                                OutlinedTextField(
                                    value = videoPriceDh,
                                    onValueChange = { videoPriceDh = it },
                                    label = { Text("سعر البيع المقترح بالمغرب (درهم)") },
                                    leadingIcon = { Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = MoroccanGold) },
                                    modifier = Modifier.fillMaxWidth().testTag("product_price_input"),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = EmeraldPrimary,
                                        unfocusedBorderColor = DarkBorder
                                    )
                                )

                                // Duration Selector
                                Text("⏱️ مدة الفيديو الإعلاني:", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf(
                                        8 to "8 ثواني (30 نقطة)",
                                        15 to "15 ثانية (50 نقطة)",
                                        20 to "20 ثانية (70 نقطة)"
                                    ).forEach { (dur, label) ->
                                        ElevatedFilterChip(
                                            selected = videoDuration == dur,
                                            onClick = { videoDuration = dur },
                                            label = { Text(label, fontSize = 12.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                // Aspect Ratio Selector
                                Text("📐 مقاس وأبعاد الفيديو:", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("9:16" to "9:16 تيك توك وريلز", "1:1" to "1:1 مربع فيسبوك", "16:9" to "16:9 شاشة عريضة").forEach { (r, label) ->
                                        ElevatedFilterChip(
                                            selected = videoRatio == r,
                                            onClick = { videoRatio = r },
                                            label = { Text(label, fontSize = 12.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                // Voice Selector
                                Text("🎙️ صوت ونبرة الإعلان:", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("شاب مغربي تجاري", "شابة مغربية ناعمة", "صوت حماسي تيك توك").forEach { v ->
                                        ElevatedFilterChip(
                                            selected = videoVoice.contains(v),
                                            onClick = { videoVoice = v },
                                            label = { Text(v, fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // Generate Video Ad Button
                                val cost = when (videoDuration) { 15 -> 50; 20 -> 70; else -> 30 }
                                val hasCredits = (user?.creditsBalance ?: 0) >= cost

                                Button(
                                    onClick = {
                                        if (hasCredits) {
                                            viewModel.generateVideo(
                                                productName = videoProductName,
                                                description = videoDescription,
                                                priceDh = videoPriceDh,
                                                audience = videoAudience,
                                                objective = videoObjective,
                                                language = videoLanguage,
                                                voiceStyle = videoVoice,
                                                style = videoStyle,
                                                durationSeconds = videoDuration,
                                                aspectRatio = videoRatio,
                                                imageBitmap = null
                                            )
                                        } else {
                                            onNavigateToCredits()
                                        }
                                    },
                                    enabled = !isGenerating,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (hasCredits) EmeraldPrimary else MoroccanGold
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(52.dp)
                                        .testTag("generate_video_button")
                                ) {
                                    if (isGenerating) {
                                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp))
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(progressText.ifBlank { "جارٍ إنشاء الفيديو..." })
                                    } else {
                                        Icon(Icons.Default.MovieFilter, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            if (hasCredits) "اصنع الفيديو الإعلاني الآن ($cost نقطة)"
                                            else "رصيدك غير كافٍ ($cost نقطة مطلوبة) - شحن الآن"
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                "ANALYSIS" -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MoroccanGold.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "دراسة جدوى المنتوج الرابح وهوامش الربح 📊",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "تحليل واقعي للسوق المغربي: احتساب سعر البيع، مصاريف الشحن والتوصيل، ونسبة استلام الدفع عند الاستلام (COD).",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )

                                OutlinedTextField(
                                    value = anaProductName,
                                    onValueChange = { anaProductName = it },
                                    label = { Text("اسم المنتوج المراد تحليله") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = anaCostDh,
                                    onValueChange = { anaCostDh = it },
                                    label = { Text("سعر الشراء من درب عمر أو كراج علال (درهم)") },
                                    leadingIcon = { Icon(Icons.Default.AttachMoney, contentDescription = null, tint = MoroccanGold) },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                OutlinedTextField(
                                    value = anaCategory,
                                    onValueChange = { anaCategory = it },
                                    label = { Text("تصنيف المنتوج") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                Button(
                                    onClick = {
                                        viewModel.analyzeProduct(anaProductName, anaCategory, anaCostDh, anaCountry, null)
                                    },
                                    enabled = !isGenerating,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MoroccanGold),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) {
                                    if (isGenerating) {
                                        CircularProgressIndicator(color = OnGold, modifier = Modifier.size(20.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("جارٍ دراسة السوق...", color = OnGold)
                                    } else {
                                        Icon(Icons.Default.Analytics, contentDescription = null, tint = OnGold)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("بدء التحليل الشامل (3 نقاط)", color = OnGold, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                "SCRIPT" -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "مولد سكربتات الدارجة المغربية 📝",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "نصوص إعلانية مبهرة بالدارجة للتيك توك وفيسبوك، ومكالمات تأكيد الواتساب لرفع التوصيل.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )

                                OutlinedTextField(
                                    value = scriptProduct,
                                    onValueChange = { scriptProduct = it },
                                    label = { Text("المنتوج") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text("نوع السكربت المطلوب:", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                                listOf(
                                    "فيديو UGC تيك توك عفوي ومقنع",
                                    "سكربت مكالمة واتساب لتأكيد الطلبية (COD Call)",
                                    "إعلان فيسبوك وانستغرام مباشر مع صدمة وعرض"
                                ).forEach { type ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.clickable { scriptType = type }
                                    ) {
                                        RadioButton(selected = scriptType == type, onClick = { scriptType = type })
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(type, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                                    }
                                }

                                Button(
                                    onClick = { viewModel.generateScript(scriptProduct, scriptType, scriptTone) },
                                    enabled = !isGenerating,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) {
                                    Icon(Icons.Default.EditNote, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("صياغة السكربت (1 نقطة)")
                                }
                            }
                        }
                    }
                }

                "IMAGE" -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StatusPending.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "ستوديو التصوير بالذكاء الاصطناعي 📸",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "تصوير منتوجك في بيئات مغربية فاخرة واستوديوهات احترافية بدون كاميرا باهظة.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )

                                OutlinedTextField(
                                    value = photoProduct,
                                    onValueChange = { photoProduct = it },
                                    label = { Text("اسم ونوع المنتوج") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = photoStyle,
                                    onValueChange = { photoStyle = it },
                                    label = { Text("الخلفية والستايل المطلوب") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = { viewModel.generateImage(photoProduct, photoStyle) },
                                    enabled = !isGenerating,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusPending),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                ) {
                                    Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("توليد صورة الاستوديو (5 نقاط)", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                "CHAT" -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA855F7).copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.size(32.dp).clip(CircleShape).background(Color(0xFFA855F7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                    }
                                    Text(
                                        text = "صابر - مستشار التجارة الإلكترونية 💬",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                }

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(260.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkBackground)
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    chatMessages.takeLast(4).forEach { (userMsg, botMsg) ->
                                        if (userMsg.isNotBlank()) {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                                Surface(
                                                    color = EmeraldPrimary,
                                                    shape = RoundedCornerShape(12.dp)
                                                ) {
                                                    Text(userMsg, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                                                }
                                            }
                                        }
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                                            Surface(
                                                color = DarkSurfaceElevated,
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Text(botMsg, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                                            }
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = chatInput,
                                        onValueChange = { chatInput = it },
                                        placeholder = { Text("سول صابر على الشحن، الإعلانات، السلعة...") },
                                        modifier = Modifier.weight(1f),
                                        singleLine = true
                                    )
                                    IconButton(
                                        onClick = {
                                            val msg = chatInput
                                            chatInput = ""
                                            viewModel.sendChatMessage(msg)
                                        },
                                        modifier = Modifier.background(EmeraldPrimary, CircleShape)
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
