package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        TransactionEntity::class,
        PaymentRequestEntity::class,
        GeneratedContentEntity::class,
        NotificationEntity::class,
        AppConfigEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SaberDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun paymentDao(): PaymentDao
    abstract fun contentDao(): ContentDao
    abstract fun notificationDao(): NotificationDao
    abstract fun configDao(): ConfigDao

    companion object {
        @Volatile
        private var INSTANCE: SaberDatabase? = null

        fun getDatabase(context: Context): SaberDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SaberDatabase::class.java,
                    "saber_maroc_seller_ai.db"
                )
                .addCallback(DatabaseCallback())
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateInitialData(database)
                    }
                }
            }
        }

        private suspend fun populateInitialData(db: SaberDatabase) {
            // Seed default Admin Account
            val adminUser = UserEntity(
                userId = "SBR-ADMIN-001",
                fullName = "SABER Maroc Admin",
                email = "admin@sabermaroc.ai",
                passwordHash = "admin123",
                phone = "+212 661 00 00 00",
                businessType = "Platform Administrator",
                creditsBalance = 9999,
                isAdmin = true,
                isTrialActive = false
            )
            db.userDao().insertUser(adminUser)

            // Seed Demo Moroccan Seller Account
            val demoUser = UserEntity(
                userId = "SBR-782914",
                fullName = "ياسين التازي (Yassine Tazi)",
                email = "seller@maroc.ma",
                passwordHash = "123456",
                phone = "+212 612 34 56 78",
                businessType = "E-commerce & Dropshipping Maroc",
                creditsBalance = 40, // Free trial credits
                isAdmin = false,
                isTrialActive = true,
                trialVideosCount = 1,
                trialAnalysesCount = 1,
                trialScriptsCount = 3
            )
            db.userDao().insertUser(demoUser)

            // Initial Trial Transaction Ledger
            db.transactionDao().insertTransaction(
                TransactionEntity(
                    transactionId = "TXN-TRIAL-INIT",
                    userId = "SBR-782914",
                    type = "FREE_TRIAL_BONUS",
                    credits = 40,
                    amountDh = 0.0,
                    status = "SUCCESS",
                    description = "هدية التسجيل والتجربة المجانية (Free Trial Signup Bonus)"
                )
            )

            // Default App Configurations
            val configs = listOf(
                AppConfigEntity("cost_script", "1"),
                AppConfigEntity("cost_product_analysis", "3"),
                AppConfigEntity("cost_image", "5"),
                AppConfigEntity("cost_voice", "10"),
                AppConfigEntity("cost_video_8s", "30"),
                AppConfigEntity("cost_video_15s", "50"),
                AppConfigEntity("cost_video_20s", "70"),
                AppConfigEntity("cash_plus_rib", "3000 0123 4567 8901 2345 6789"),
                AppConfigEntity("cash_plus_beneficiary", "SABER MAROC SARL - E-COMMERCE AI"),
                AppConfigEntity("cash_plus_agency_city", "Casablanca / Rabat / Marrakech"),
                AppConfigEntity("ai_provider_primary", "Runware / Gemini AI Engine"),
                AppConfigEntity("ai_provider_status", "ACTIVE_ONLINE"),
                AppConfigEntity("free_trial_credits", "40")
            )
            configs.forEach { db.configDao().setConfig(it) }

            // Welcome Notification
            db.notificationDao().insertNotification(
                NotificationEntity(
                    userId = "SBR-782914",
                    title = "مرحباً بك في SABER Maroc Seller AI! 🚀",
                    message = "تم تفعيل حسابك بنجاح وحصلت على 40 نقطة تجريبية مجانية لإنشاء أول فيديو إعلاني وتحليل المنتوجات الرابحة.",
                    type = "TRIAL"
                )
            )
        }
    }
}
