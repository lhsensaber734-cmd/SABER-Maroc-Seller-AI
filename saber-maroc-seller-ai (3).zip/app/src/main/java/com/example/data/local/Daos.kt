package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    fun getUserByIdFlow(userId: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Query("SELECT COUNT(*) FROM users")
    suspend fun getTotalUsersCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET creditsBalance = creditsBalance + :amount WHERE userId = :userId")
    suspend fun addCredits(userId: String, amount: Int): Int

    @Query("UPDATE users SET creditsBalance = creditsBalance - :amount WHERE userId = :userId AND creditsBalance >= :amount")
    suspend fun deductCredits(userId: String, amount: Int): Int

    @Query("UPDATE users SET passwordHash = :newHash WHERE email = :email")
    suspend fun updatePasswordByEmail(email: String, newHash: String): Int
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsForUser(userId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(txn: TransactionEntity)

    @Query("SELECT SUM(credits) FROM transactions WHERE type = 'TOPUP' AND status = 'SUCCESS'")
    suspend fun getTotalCreditsSold(): Int?

    @Query("SELECT SUM(credits) FROM transactions WHERE type = 'AI_USAGE' AND status = 'SUCCESS'")
    suspend fun getTotalCreditsUsed(): Int?

    @Query("SELECT SUM(amountDh) FROM transactions WHERE type = 'TOPUP' AND status = 'SUCCESS'")
    suspend fun getTotalRevenueDh(): Double?
}

@Dao
interface PaymentDao {
    @Query("SELECT * FROM payment_requests WHERE userId = :userId ORDER BY dateTimestamp DESC")
    fun getPaymentsForUser(userId: String): Flow<List<PaymentRequestEntity>>

    @Query("SELECT * FROM payment_requests ORDER BY dateTimestamp DESC")
    fun getAllPayments(): Flow<List<PaymentRequestEntity>>

    @Query("SELECT * FROM payment_requests WHERE status = 'PENDING' ORDER BY dateTimestamp ASC")
    fun getPendingPayments(): Flow<List<PaymentRequestEntity>>

    @Query("SELECT COUNT(*) FROM payment_requests WHERE status = 'PENDING'")
    suspend fun getPendingCount(): Int

    @Query("SELECT * FROM payment_requests WHERE requestId = :requestId LIMIT 1")
    suspend fun getPaymentById(requestId: String): PaymentRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPaymentRequest(payment: PaymentRequestEntity)

    @Update
    suspend fun updatePaymentRequest(payment: PaymentRequestEntity)
}

@Dao
interface ContentDao {
    @Query("SELECT * FROM generated_content WHERE userId = :userId ORDER BY createdAt DESC")
    fun getContentForUser(userId: String): Flow<List<GeneratedContentEntity>>

    @Query("SELECT * FROM generated_content WHERE userId = :userId AND toolType = :toolType ORDER BY createdAt DESC")
    fun getContentForUserByType(userId: String, toolType: String): Flow<List<GeneratedContentEntity>>

    @Query("SELECT * FROM generated_content ORDER BY createdAt DESC")
    fun getAllContent(): Flow<List<GeneratedContentEntity>>

    @Query("SELECT COUNT(*) FROM generated_content WHERE toolType = 'VIDEO'")
    suspend fun getVideosCount(): Int

    @Query("SELECT COUNT(*) FROM generated_content WHERE toolType = 'IMAGE'")
    suspend fun getImagesCount(): Int

    @Query("SELECT COUNT(*) FROM generated_content")
    suspend fun getTotalAIGenerationsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContent(content: GeneratedContentEntity)

    @Delete
    suspend fun deleteContent(content: GeneratedContentEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId OR userId = 'ALL' ORDER BY timestamp DESC")
    fun getNotificationsForUser(userId: String): Flow<List<NotificationEntity>>

    @Query("SELECT * FROM notifications WHERE userId = 'ADMIN' ORDER BY timestamp DESC")
    fun getAdminNotifications(): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE (userId = :userId OR userId = 'ALL') AND isRead = 0")
    fun getUnreadCount(userId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId OR userId = 'ALL'")
    suspend fun markAllAsRead(userId: String)
}

@Dao
interface ConfigDao {
    @Query("SELECT * FROM app_configs")
    fun getAllConfigs(): Flow<List<AppConfigEntity>>

    @Query("SELECT value FROM app_configs WHERE `key` = :key LIMIT 1")
    suspend fun getConfigValue(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setConfig(config: AppConfigEntity)
}
