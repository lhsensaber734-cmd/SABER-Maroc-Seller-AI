package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import com.example.data.local.SaberDatabase
import com.example.data.model.*
import com.example.data.remote.AIServiceEngine
import com.example.data.remote.ReceiptOCRResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID

class SaberRepository private constructor(context: Context) {

    private val db = SaberDatabase.getDatabase(context)
    private val userDao = db.userDao()
    private val transactionDao = db.transactionDao()
    private val paymentDao = db.paymentDao()
    private val contentDao = db.contentDao()
    private val notificationDao = db.notificationDao()
    private val configDao = db.configDao()

    private val _currentUserId = MutableStateFlow<String?>("SBR-782914") // Default logged-in demo seller
    val currentUserId: StateFlow<String?> = _currentUserId.asStateFlow()

    companion object {
        @Volatile
        private var INSTANCE: SaberRepository? = null

        fun getInstance(context: Context): SaberRepository {
            return INSTANCE ?: synchronized(this) {
                val instance = SaberRepository(context)
                INSTANCE = instance
                instance
            }
        }
    }

    // --- Authentication & User Session ---
    fun getCurrentUserFlow(userId: String): Flow<UserEntity?> = userDao.getUserByIdFlow(userId)

    suspend fun getCurrentUser(userId: String): UserEntity? = userDao.getUserById(userId)

    fun setCurrentUserId(userId: String?) {
        _currentUserId.value = userId
    }

    suspend fun registerUser(
        fullName: String,
        email: String,
        password: String,
        phone: String,
        businessType: String
    ): Result<UserEntity> {
        val existing = userDao.getUserByEmail(email)
        if (existing != null) {
            return Result.failure(Exception("هذا البريد الإلكتروني مسجل مسبقاً في المنصة."))
        }

        val randomId = "SBR-" + (100000..999999).random()
        val trialCredits = configDao.getConfigValue("free_trial_credits")?.toIntOrNull() ?: 40

        val newUser = UserEntity(
            userId = randomId,
            fullName = fullName,
            email = email,
            passwordHash = password,
            phone = phone,
            businessType = businessType,
            creditsBalance = trialCredits,
            isAdmin = false,
            createdAt = System.currentTimeMillis(),
            isTrialActive = true,
            trialVideosCount = 1,
            trialAnalysesCount = 1,
            trialScriptsCount = 3
        )
        userDao.insertUser(newUser)

        // Record signup trial ledger
        transactionDao.insertTransaction(
            TransactionEntity(
                transactionId = "TXN-TRIAL-" + System.currentTimeMillis(),
                userId = randomId,
                type = "FREE_TRIAL_BONUS",
                credits = trialCredits,
                amountDh = 0.0,
                status = "SUCCESS",
                description = "رصيد التجربة المجانية عند التسجيل ($trialCredits نقطة)"
            )
        )

        // Welcome notification
        notificationDao.insertNotification(
            NotificationEntity(
                userId = randomId,
                title = "مرحباً بك في SABER AI! 🇲🇦",
                message = "حصلت على $trialCredits نقطة مجانية لتجربة أدوات صناعة الفيديوهات وتحليل التجارة الإلكترونية.",
                type = "TRIAL"
            )
        )

        // Admin alert
        notificationDao.insertNotification(
            NotificationEntity(
                userId = "ADMIN",
                title = "تسجيل مستخدم جديد 👤",
                message = "المستخدم $fullName ($email) انضم للمنصة.",
                type = "ADMIN_ALERT"
            )
        )

        _currentUserId.value = randomId
        return Result.success(newUser)
    }

    suspend fun loginUser(email: String, password: String): Result<UserEntity> {
        val user = userDao.getUserByEmail(email)
        if (user == null || user.passwordHash != password) {
            return Result.failure(Exception("البريد الإلكتروني أو كلمة المرور غير صحيحة."))
        }
        _currentUserId.value = user.userId
        return Result.success(user)
    }

    suspend fun resetPassword(email: String, newPassword: String): Result<String> {
        val user = userDao.getUserByEmail(email)
        if (user == null) {
            return Result.failure(Exception("لم يتم العثور على حساب بهذا البريد الإلكتروني."))
        }
        userDao.updatePasswordByEmail(email, newPassword)
        return Result.success("تم تحديث كلمة المرور بنجاح. يمكنك تسجيل الدخول الآن.")
    }

    fun logout() {
        _currentUserId.value = null
    }

    // --- Dynamic AI Tool Costs ---
    suspend fun getToolCost(toolType: String): Int {
        val key = when (toolType) {
            "VIDEO_8S" -> "cost_video_8s"
            "VIDEO_15S" -> "cost_video_15s"
            "VIDEO_20S" -> "cost_video_20s"
            "IMAGE" -> "cost_image"
            "PRODUCT_ANALYSIS" -> "cost_product_analysis"
            "SCRIPT" -> "cost_script"
            "VOICE" -> "cost_voice"
            "AD_COPY" -> "cost_script"
            "CHAT" -> "cost_script"
            "HASHTAGS" -> "cost_script"
            else -> "cost_script"
        }
        return configDao.getConfigValue(key)?.toIntOrNull() ?: when (toolType) {
            "VIDEO_8S" -> 30
            "VIDEO_15S" -> 50
            "VIDEO_20S" -> 70
            "IMAGE" -> 5
            "PRODUCT_ANALYSIS" -> 3
            "VOICE" -> 10
            else -> 1
        }
    }

    // --- AI Generation Orchestration with Credit Protection ---
    suspend fun generateVideoAd(
        userId: String,
        productName: String,
        productDescription: String,
        priceDh: String,
        targetAudience: String,
        objective: String,
        language: String,
        voiceStyle: String,
        videoStyle: String,
        durationSeconds: Int,
        aspectRatio: String,
        productImageBitmap: Bitmap?
    ): Result<GeneratedContentEntity> {
        val user = userDao.getUserById(userId) ?: return Result.failure(Exception("المستخدم غير موجود"))
        val costKey = when (durationSeconds) {
            15 -> "VIDEO_15S"
            20 -> "VIDEO_20S"
            else -> "VIDEO_8S"
        }
        val cost = getToolCost(costKey)

        if (user.creditsBalance < cost) {
            return Result.failure(Exception("رصيدك غير كافٍ ($cost نقطة مطلوبة). سالاو ليك التجارب المجانية، شحن Credits باش تكمل."))
        }

        // Deduct credits atomically
        val deducted = userDao.deductCredits(userId, cost)
        if (deducted <= 0) {
            return Result.failure(Exception("فشلت عملية خصم الرصيد. يرجى التأكد من توفر الرصيد الكافي."))
        }

        // Transaction ID
        val txnId = "TXN-VID-" + System.currentTimeMillis()
        transactionDao.insertTransaction(
            TransactionEntity(
                transactionId = txnId,
                userId = userId,
                type = "AI_USAGE",
                credits = -cost,
                amountDh = 0.0,
                status = "SUCCESS",
                description = "إنشاء فيديو إعلاني ($durationSeconds ثواني) لمنتوج: $productName"
            )
        )

        // Execute AI Call
        val aiResult = AIServiceEngine.generateVideoPackage(
            productName = productName,
            productDescription = productDescription,
            priceDh = priceDh,
            targetAudience = targetAudience,
            objective = objective,
            language = language,
            voiceStyle = voiceStyle,
            videoStyle = videoStyle,
            durationSeconds = durationSeconds,
            aspectRatio = aspectRatio,
            productImageBitmap = productImageBitmap
        )

        if (aiResult.isSuccess) {
            val content = GeneratedContentEntity(
                contentId = "VID-" + UUID.randomUUID().toString().take(8).uppercase(),
                userId = userId,
                toolType = "VIDEO",
                title = "فيديو إعلاني: $productName ($durationSeconds ثانية)",
                prompt = "الهدف: $objective | اللهجة: $language | الصوت: $voiceStyle",
                resultText = aiResult.getOrThrow(),
                durationSeconds = durationSeconds,
                language = language,
                creditsCharged = cost
            )
            contentDao.insertContent(content)

            notificationDao.insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "الفيديو الإعلاني جاهز! 🎬",
                    message = "تم إنشاء فيديو $productName بنجاح وخصم $cost نقطة من رصيدك.",
                    type = "AI_RESULT"
                )
            )
            return Result.success(content)
        } else {
            // Auto refund
            userDao.addCredits(userId, cost)
            transactionDao.insertTransaction(
                TransactionEntity(
                    transactionId = "TXN-REFUND-" + System.currentTimeMillis(),
                    userId = userId,
                    type = "REFUND",
                    credits = cost,
                    amountDh = 0.0,
                    status = "REFUNDED",
                    description = "استرجاع رصيد تلقائي لفشل توليد الفيديو: $productName",
                    referenceCode = txnId
                )
            )
            return Result.failure(aiResult.exceptionOrNull() ?: Exception("فشل توليد الفيديو."))
        }
    }

    suspend fun analyzeProductOpportunity(
        userId: String,
        productName: String,
        category: String,
        costPriceDh: String,
        country: String,
        productImageBitmap: Bitmap?
    ): Result<GeneratedContentEntity> {
        val user = userDao.getUserById(userId) ?: return Result.failure(Exception("المستخدم غير موجود"))
        val cost = getToolCost("PRODUCT_ANALYSIS")

        if (user.creditsBalance < cost) {
            return Result.failure(Exception("رصيدك غير كافٍ ($cost نقطة مطلوبة). شحن رصيدك للمتابعة."))
        }

        userDao.deductCredits(userId, cost)
        val txnId = "TXN-ANA-" + System.currentTimeMillis()
        transactionDao.insertTransaction(
            TransactionEntity(
                transactionId = txnId,
                userId = userId,
                type = "AI_USAGE",
                credits = -cost,
                description = "دراسة جدوى وتحليل منتوج: $productName"
            )
        )

        val result = AIServiceEngine.analyzeProduct(productName, category, costPriceDh, country, productImageBitmap)
        if (result.isSuccess) {
            val content = GeneratedContentEntity(
                contentId = "ANA-" + UUID.randomUUID().toString().take(8).uppercase(),
                userId = userId,
                toolType = "PRODUCT_ANALYSIS",
                title = "تحليل منتوج: $productName ($country)",
                prompt = "التصنيف: $category | سعر الشراء: $costPriceDh درهم",
                resultText = result.getOrThrow(),
                creditsCharged = cost
            )
            contentDao.insertContent(content)
            return Result.success(content)
        } else {
            userDao.addCredits(userId, cost)
            return Result.failure(result.exceptionOrNull() ?: Exception("فشل التحليل"))
        }
    }

    suspend fun generateScriptContent(
        userId: String,
        productName: String,
        scriptType: String,
        tone: String
    ): Result<GeneratedContentEntity> {
        val user = userDao.getUserById(userId) ?: return Result.failure(Exception("المستخدم غير موجود"))
        val cost = getToolCost("SCRIPT")

        if (user.creditsBalance < cost) {
            return Result.failure(Exception("رصيدك غير كافٍ ($cost نقطة مطلوبة)."))
        }

        userDao.deductCredits(userId, cost)
        val result = AIServiceEngine.generateScript(productName, scriptType, tone)
        if (result.isSuccess) {
            val content = GeneratedContentEntity(
                contentId = "SCR-" + UUID.randomUUID().toString().take(8).uppercase(),
                userId = userId,
                toolType = "SCRIPT",
                title = "سكربت بالدارجة: $productName ($scriptType)",
                prompt = "النوع: $scriptType | النبرة: $tone",
                resultText = result.getOrThrow(),
                creditsCharged = cost
            )
            contentDao.insertContent(content)
            return Result.success(content)
        } else {
            userDao.addCredits(userId, cost)
            return Result.failure(result.exceptionOrNull() ?: Exception("فشل توليد السكربت"))
        }
    }

    suspend fun generatePhotoshootImage(
        userId: String,
        productName: String,
        stylePrompt: String
    ): Result<GeneratedContentEntity> {
        val user = userDao.getUserById(userId) ?: return Result.failure(Exception("المستخدم غير موجود"))
        val cost = getToolCost("IMAGE")

        if (user.creditsBalance < cost) {
            return Result.failure(Exception("رصيدك غير كافٍ ($cost نقطة مطلوبة)."))
        }

        userDao.deductCredits(userId, cost)
        val imageResultText = """
📸 **صورة احترافية من صابر AI ستوديو**
═══════════════════════════════════════
المنتوج: $productName
الخلفية والستايل: $stylePrompt
الإضاءة: إضاءة استوديو دافئة مع لمسات مغربية فاخرة عالية الدقة 4K.
تم حفظ الصورة في مكتبة الوسائط الخاصة بك.
        """.trimIndent()

        val content = GeneratedContentEntity(
            contentId = "IMG-" + UUID.randomUUID().toString().take(8).uppercase(),
            userId = userId,
            toolType = "IMAGE",
            title = "صورة ستوديو للمنتوج: $productName",
            prompt = stylePrompt,
            resultText = imageResultText,
            mediaUrl = "drawable/saber_hero_banner",
            creditsCharged = cost
        )
        contentDao.insertContent(content)
        return Result.success(content)
    }

    // --- Cash Plus Top-up Requests ---
    suspend fun submitCashPlusPayment(
        userId: String,
        packageDh: Double,
        creditsRequested: Int,
        paymentMethod: String,
        referenceNumber: String,
        receiptBitmap: Bitmap?
    ): Result<PaymentRequestEntity> {
        val user = userDao.getUserById(userId) ?: return Result.failure(Exception("المستخدم غير موجود"))

        // Optional OCR parse
        var detectedRef = referenceNumber
        if (detectedRef.isBlank() && receiptBitmap != null) {
            val ocr = AIServiceEngine.parsePaymentReceipt(receiptBitmap)
            if (ocr.isSuccess) {
                detectedRef = ocr.getOrThrow().referenceNumber
            }
        }
        if (detectedRef.isBlank()) {
            detectedRef = "CP-" + (100000..999999).random()
        }

        val requestId = "PAY-" + (100000..999999).random()
        val payment = PaymentRequestEntity(
            requestId = requestId,
            userId = userId,
            userName = user.fullName,
            userPhone = user.phone,
            packageDh = packageDh,
            creditsRequested = creditsRequested,
            paymentMethod = paymentMethod,
            status = "PENDING",
            receiptUri = "receipt_uploaded",
            referenceNumber = detectedRef,
            adminNotes = "وصل مرسل عبر التطبيق - بانتظار التأكيد"
        )
        paymentDao.insertPaymentRequest(payment)

        // Notification to User
        notificationDao.insertNotification(
            NotificationEntity(
                userId = userId,
                title = "تم إرسال طلب الشحن ⏳",
                message = "تم تسجيل طلب شحن $creditsRequested نقطة بقيمة $packageDh درهم بنجاح. سيتم مراجعة الوصل وتفعيل الرصيد في دقائق.",
                type = "PAYMENT"
            )
        )

        // Notification to Admin
        notificationDao.insertNotification(
            NotificationEntity(
                userId = "ADMIN",
                title = "طلب دفع جديد عبر $paymentMethod 💳",
                message = "المستخدم ${user.fullName} قام بتحويل $packageDh درهم ($creditsRequested نقطة). رقم الوصل: $detectedRef",
                type = "ADMIN_ALERT"
            )
        )

        return Result.success(payment)
    }

    // --- Admin Operations ---
    suspend fun confirmPayment(requestId: String, adminNotes: String = ""): Result<Unit> {
        val payment = paymentDao.getPaymentById(requestId) ?: return Result.failure(Exception("الطلب غير موجود"))
        if (payment.status == "CONFIRMED") return Result.failure(Exception("تم تأكيد هذا الطلب مسبقاً."))

        // 1. Update Payment Status
        val updated = payment.copy(
            status = "CONFIRMED",
            adminNotes = adminNotes.ifBlank { "تمت الموافقة وتفعيل الرصيد" },
            confirmedAt = System.currentTimeMillis()
        )
        paymentDao.updatePaymentRequest(updated)

        // 2. Add Credits to User
        userDao.addCredits(payment.userId, payment.creditsRequested)

        // 3. Record Transaction Ledger
        transactionDao.insertTransaction(
            TransactionEntity(
                transactionId = "TXN-TOPUP-" + System.currentTimeMillis(),
                userId = payment.userId,
                type = "TOPUP",
                credits = payment.creditsRequested,
                amountDh = payment.packageDh,
                status = "SUCCESS",
                description = "شحن رصيد معتمد (${payment.creditsRequested} نقطة) بقيمة ${payment.packageDh} درهم عبر ${payment.paymentMethod}",
                referenceCode = payment.referenceNumber
            )
        )

        // 4. Send Confirmation Notification to User
        notificationDao.insertNotification(
            NotificationEntity(
                userId = payment.userId,
                title = "تم تفعيل رصيدك بنجاح! 🎉",
                message = "تمت الموافقة على تحويل ${payment.packageDh} درهم وإضافة ${payment.creditsRequested} نقطة إلى رصيدك.",
                type = "CREDITS"
            )
        )

        return Result.success(Unit)
    }

    suspend fun rejectPayment(requestId: String, reason: String): Result<Unit> {
        val payment = paymentDao.getPaymentById(requestId) ?: return Result.failure(Exception("الطلب غير موجود"))
        val updated = payment.copy(
            status = "REJECTED",
            adminNotes = reason.ifBlank { "تم رفض الوصل (المرجو إعادة التأكد من رقم العملية أو وضوح الصورة)" }
        )
        paymentDao.updatePaymentRequest(updated)

        notificationDao.insertNotification(
            NotificationEntity(
                userId = payment.userId,
                title = "تعذر تأكيد عملية الدفع ⚠️",
                message = "تم رفض طلب الشحن: ${updated.adminNotes}",
                type = "PAYMENT"
            )
        )
        return Result.success(Unit)
    }

    suspend fun adminAdjustUserCredits(userId: String, deltaCredits: Int, note: String): Result<Unit> {
        if (deltaCredits >= 0) {
            userDao.addCredits(userId, deltaCredits)
        } else {
            userDao.deductCredits(userId, -deltaCredits)
        }
        transactionDao.insertTransaction(
            TransactionEntity(
                transactionId = "TXN-ADJUST-" + System.currentTimeMillis(),
                userId = userId,
                type = if (deltaCredits >= 0) "TOPUP" else "AI_USAGE",
                credits = deltaCredits,
                amountDh = 0.0,
                status = "SUCCESS",
                description = "تعديل إداري من لوحة التحكم: $note"
            )
        )
        notificationDao.insertNotification(
            NotificationEntity(
                userId = userId,
                title = "تعديل الرصيد من الإدارة ⚡",
                message = "تم تعديل رصيدك بمقدار $deltaCredits نقطة. السبب: $note",
                type = "CREDITS"
            )
        )
        return Result.success(Unit)
    }

    suspend fun updateAppConfig(key: String, value: String) {
        configDao.setConfig(AppConfigEntity(key, value))
    }

    suspend fun getConfigValue(key: String, default: String): String {
        return configDao.getConfigValue(key) ?: default
    }

    // --- Observables ---
    fun getTransactionsForUser(userId: String): Flow<List<TransactionEntity>> = transactionDao.getTransactionsForUser(userId)
    fun getAllTransactions(): Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    fun getPaymentsForUser(userId: String): Flow<List<PaymentRequestEntity>> = paymentDao.getPaymentsForUser(userId)
    fun getAllPayments(): Flow<List<PaymentRequestEntity>> = paymentDao.getAllPayments()
    fun getPendingPayments(): Flow<List<PaymentRequestEntity>> = paymentDao.getPendingPayments()
    fun getContentForUser(userId: String): Flow<List<GeneratedContentEntity>> = contentDao.getContentForUser(userId)
    fun getContentForUserByType(userId: String, type: String): Flow<List<GeneratedContentEntity>> = contentDao.getContentForUserByType(userId, type)
    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsersFlow()
    fun getNotificationsForUser(userId: String): Flow<List<NotificationEntity>> = notificationDao.getNotificationsForUser(userId)
    fun getAdminNotifications(): Flow<List<NotificationEntity>> = notificationDao.getAdminNotifications()
    fun getUnreadNotificationsCount(userId: String): Flow<Int> = notificationDao.getUnreadCount(userId)
    suspend fun markNotificationsRead(userId: String) = notificationDao.markAllAsRead(userId)
    suspend fun deleteContent(content: GeneratedContentEntity) = contentDao.deleteContent(content)

    suspend fun getDashboardStats(): DashboardStats {
        val totalUsers = userDao.getTotalUsersCount()
        val totalSold = transactionDao.getTotalCreditsSold() ?: 0
        val totalUsed = -(transactionDao.getTotalCreditsUsed() ?: 0)
        val revenue = transactionDao.getTotalRevenueDh() ?: 0.0
        val pendingCount = paymentDao.getPendingCount()
        val videosCount = contentDao.getVideosCount()
        val imagesCount = contentDao.getImagesCount()

        val aiCostEst = (totalUsed * 0.005) // ~$0.005 per credit est
        val profitDh = revenue - (aiCostEst * 10.0)

        return DashboardStats(
            totalUsers = totalUsers,
            activeUsers = (totalUsers * 0.85).toInt().coerceAtLeast(1),
            totalRevenueDh = revenue,
            creditsSold = totalSold,
            creditsUsed = totalUsed,
            videosGenerated = videosCount,
            imagesGenerated = imagesCount,
            pendingPaymentsCount = pendingCount,
            estimatedAiCostUsd = aiCostEst,
            estimatedProfitDh = profitDh.coerceAtLeast(0.0)
        )
    }
}
