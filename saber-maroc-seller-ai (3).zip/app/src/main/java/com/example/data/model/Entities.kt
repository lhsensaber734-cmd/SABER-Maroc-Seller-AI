package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val userId: String, // e.g. "SBR-829314"
    val fullName: String,
    val email: String,
    val passwordHash: String,
    val phone: String,
    val businessType: String = "E-commerce Seller", // E-commerce / Content Creator / Dropshipping / Brand
    val creditsBalance: Int = 40,
    val isAdmin: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val isTrialActive: Boolean = true,
    val trialVideosCount: Int = 1,
    val trialAnalysesCount: Int = 1,
    val trialScriptsCount: Int = 3
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: String, // e.g. "TXN-9182374"
    val userId: String,
    val type: String, // "TOPUP", "AI_USAGE", "REFUND", "FREE_TRIAL_BONUS"
    val credits: Int, // positive for addition, negative for deduction
    val amountDh: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "SUCCESS", // "SUCCESS", "PENDING", "REJECTED", "REFUNDED"
    val description: String,
    val referenceCode: String = ""
)

@Entity(tableName = "payment_requests")
data class PaymentRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val requestId: String, // e.g. "PAY-284910"
    val userId: String,
    val userName: String,
    val userPhone: String,
    val packageDh: Double, // 20, 50, 100, 200
    val creditsRequested: Int,
    val paymentMethod: String = "Cash Plus", // Cash Plus / CIH Bank / Attijariwafa
    val dateTimestamp: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // "PENDING", "CONFIRMED", "REJECTED"
    val receiptUri: String = "",
    val referenceNumber: String = "",
    val adminNotes: String = "",
    val confirmedAt: Long? = null
)

@Entity(tableName = "generated_content")
data class GeneratedContentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contentId: String, // e.g. "GEN-91823"
    val userId: String,
    val toolType: String, // "VIDEO", "IMAGE", "SCRIPT", "PRODUCT_ANALYSIS", "VOICE", "AD_COPY", "CHAT", "HASHTAGS"
    val title: String,
    val prompt: String,
    val resultText: String,
    val mediaUrl: String? = null,
    val durationSeconds: Int = 8,
    val language: String = "الدارجة المغربية",
    val creditsCharged: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String, // specific userId or "ADMIN"
    val title: String,
    val message: String,
    val type: String, // "PAYMENT", "CREDITS", "AI_RESULT", "TRIAL", "ADMIN_ALERT"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

@Entity(tableName = "app_configs")
data class AppConfigEntity(
    @PrimaryKey val key: String,
    val value: String
)

data class CreditPackage(
    val id: String,
    val name: String,
    val priceDh: Double,
    val credits: Int,
    val bonusTag: String = "",
    val isPopular: Boolean = false,
    val description: String = ""
)

data class AIServicePricing(
    val toolType: String,
    val nameAr: String,
    val nameFr: String,
    val defaultCredits: Int,
    val descriptionAr: String
)

data class DashboardStats(
    val totalUsers: Int = 0,
    val activeUsers: Int = 0,
    val totalRevenueDh: Double = 0.0,
    val creditsSold: Int = 0,
    val creditsUsed: Int = 0,
    val videosGenerated: Int = 0,
    val imagesGenerated: Int = 0,
    val pendingPaymentsCount: Int = 0,
    val estimatedAiCostUsd: Double = 0.0,
    val estimatedProfitDh: Double = 0.0
)
